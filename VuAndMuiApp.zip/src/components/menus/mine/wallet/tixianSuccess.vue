<template>
    <div class="ct">
         <header class="mui-bar mui-bar-nav">
		    <a class="mui-action-back mui-icon mui-icon-left-nav mui-pull-left"></a>
		    <h1 class="mui-title"></h1>
		</header>
    </div>
</template>
<script>
export default {
  data() {
    return {};
  },
  mounted() {
    const self = this;
    
  },
  methods: {
      
  }
};
</script>
<style scoped>
.ct {
  width: 7rem;
  margin: 0.2rem auto;
  padding-bottom: 0.4rem;
  background: #fff;
  border-radius: 0.1rem;
  padding-left: 0.3rem;
  padding-right: 0.3rem;
  padding-top: 0.4rem;
}
.row1 {
  font-size: 0.34rem;
  color: #323232;
}
.row2 {
  padding: 0.6rem 0 0.6rem 0;
  border: 0;
  outline: none;
  border-bottom: 1px solid #e1e1e1;
  font-size: 0.7rem;
  font-weight: 600;
  color: #323232;
}
.msg {
  color: #f00;
  font-size: 0.1rem;
}
button {
  width: 5rem;
  height: 1.2rem;
  color: #ffffff;
  font-size: 0.46rem;
  text-align: center;
  background: #7e57c2;
  border-radius: 0.1rem;
  display: block;
  margin: 1.2rem auto;
  margin-bottom: 0;
}
</style>

