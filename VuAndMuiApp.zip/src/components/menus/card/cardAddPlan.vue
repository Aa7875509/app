<template>
    <div>
      <!-- 提交计划 -->
    </div>
</template>
<script>
    export default {
        data(){
            return {

            }
        },
        mounted(){
           mui.init();
        },
        methods:{
             
        }
    }
</script>
<style scoped>

</style>